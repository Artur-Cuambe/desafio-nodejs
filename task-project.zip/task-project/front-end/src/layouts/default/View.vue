<template>
  <v-main>
    <router-view />
  </v-main>
</template>

<script lang="ts" setup>
  //
</script>
