<template>
  <v-app-bar flat>
    <v-app-bar-title>
      <span><v-img src="/logo.png" width="11" alt="logo" inline/>iteki task challenge</span>
    </v-app-bar-title>
  </v-app-bar>
</template>

<script lang="ts" setup>
//
</script>
