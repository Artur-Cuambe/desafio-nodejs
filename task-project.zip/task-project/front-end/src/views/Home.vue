<template>
  <task />
</template>

<script lang="ts" setup>
  import task from '@/components/task.vue'
</script>
